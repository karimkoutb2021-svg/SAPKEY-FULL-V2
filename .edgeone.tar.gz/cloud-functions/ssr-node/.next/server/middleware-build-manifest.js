globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/X9bj8Lbz4lxb8l1e0fw7x/_buildManifest.js",
    "static/X9bj8Lbz4lxb8l1e0fw7x/_ssgManifest.js",
    "static/X9bj8Lbz4lxb8l1e0fw7x/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0hpnrek~99o9g.js",
    "static/chunks/0vu7evuxoivkb.js",
    "static/chunks/0hfw~zchjv985.js",
    "static/chunks/01.-sh3cgqu1l.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/turbopack-17yr9nhj89rx~.js"
  ]
};
